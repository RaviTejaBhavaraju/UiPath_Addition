   links {
   --System Assemblies
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/Microsoft.CSharp.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/PresentationCore.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/PresentationFramework.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Core.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Data.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Data.DataSetExtensions.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Windows.Forms.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Xaml.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Xml.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Xml.Linq.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/WindowsBase.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Net.Http.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Net.Http.WebRequest.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Web.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.ServiceModel.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.ServiceModel.Web.dll",
   "C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.5/System.Drawing.dll",
   "../packages/Newtonsoft.Json.11.0.1/lib/net45/Newtonsoft.Json.dll"
   
   
}